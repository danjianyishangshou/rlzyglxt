<template>
  <div class="setting-container">
    <div class="app-container">
      <h2>
        公司设置
      </h2>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Setting'
}
</script>

<style>

</style>

