<template>
  <div class="social-container">
    <div class="app-container">
      <h2>
        社保
      </h2>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Social'
}
</script>

<style>

</style>

