<template>
  <div class="permission-container">
    <div class="app-container">
      <h2>
        权限
      </h2>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Permission'
}
</script>

<style>

</style>

