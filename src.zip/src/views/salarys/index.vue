<template>
  <div class="salarys-container">
    <div class="app-container">
      <h2>
        工资
      </h2>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Salarys'
}
</script>

<style>

</style>

