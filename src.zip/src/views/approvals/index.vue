<template>
  <div class="approvals-container">
    <div class="app-container">
      <h2>
        审批
      </h2>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Approvals'
}
</script>

<style>

</style>

