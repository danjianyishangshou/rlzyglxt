<template>
  <div class="departments-container">
    <div class="app-container">
      <h2>
        组织架构
      </h2>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Departments'
}
</script>

<style>

</style>

