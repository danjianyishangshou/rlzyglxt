<template>
  <div class="dashboard">
    123
    <!-- <svg>
      <use xlink.href="#icon-example" />
    </svg> -->
    <svg-icon icon-class="dashboard" />
    <svg-icon icon-class="example" />
  </div>
</template>

<script>

export default {
  name: 'Dashboard'

}
</script>

<style lang="scss" scoped>

</style>
