module.exports = {
// 设置网页显示的标题=>重启项目
  title: '小柠檬人力资源管理',
  // 设置头部导航是否固定定位
  fixedHeader: true,

  // 侧边栏的logo是否打开
  sidebarLogo: true
}
